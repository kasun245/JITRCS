import 'controller/sign_in_controller.dart';
import 'package:flutter/material.dart';
import 'package:jitrcs/core/app_export.dart';
import 'package:jitrcs/core/utils/validation_functions.dart';
import 'package:jitrcs/widgets/custom_checkbox_button.dart';
import 'package:jitrcs/widgets/custom_elevated_button.dart';
import 'package:jitrcs/widgets/custom_text_form_field.dart';

// ignore_for_file: must_be_immutable
class SignInScreen extends GetWidget<SignInController> {
  SignInScreen({Key? key}) : super(key: key);

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: Form(
                key: _formKey,
                child: Container(
                    width: 414.h,
                    padding:
                        EdgeInsets.only(left: 34.h, top: 192.v, right: 34.h),
                    child: Column(children: [
                      Text("lbl_sign_in".tr, style: theme.textTheme.titleLarge),
                      Text("lbl_jitrcs".tr,
                          style: CustomTextStyles.titleLargeIndigo400),
                      SizedBox(height: 5.v),
                      Text("msg_sign_in_to_continue".tr,
                          style: CustomTextStyles
                              .titleSmallRalewayOnPrimaryContainer),
                      SizedBox(height: 56.v),
                      Align(
                          alignment: Alignment.centerLeft,
                          child: Opacity(
                              opacity: 0.7,
                              child: Text("lbl_email".tr,
                                  style: CustomTextStyles
                                      .titleLargeIndigo400))),
                      SizedBox(height: 4.v),
                      CustomTextFormField(
                          controller: controller.emailController,
                          hintText: "msg_jitrcs_gmail_com".tr,
                          textInputType: TextInputType.emailAddress,
                          prefix: Container(
                              margin:
                                  EdgeInsets.fromLTRB(12.h, 12.v, 30.h, 12.v),
                              child: CustomImageView(
                                  svgPath: ImageConstant.imgMail)),
                          prefixConstraints: BoxConstraints(maxHeight: 45.v),
                          validator: (value) {
                            if (value == null ||
                                (!isValidEmail(value, isRequired: true))) {
                              return "Please enter valid email";
                            }
                            return null;
                          }),
                      Align(
                          alignment: Alignment.centerLeft,
                          child: Opacity(
                              opacity: 0.7,
                              child: Padding(
                                  padding: EdgeInsets.only(left: 2.h, top: 20.v),
                                  child: Text("lbl_password".tr,
                                      style: CustomTextStyles
                                          .titleLargeIndigo400)))),
                      SizedBox(height: 2.v),
                      Obx(() => CustomTextFormField(
                          controller: controller.passwordController,
                          hintText: "lbl".tr,
                          hintStyle: CustomTextStyles
                              .labelLargeRalewayPrimary,
                          textInputAction: TextInputAction.done,
                          textInputType: TextInputType.visiblePassword,
                          prefix: Container(
                              margin: EdgeInsets.fromLTRB(11.h, 9.v, 21.h, 9.v),
                              child: CustomImageView(
                                  svgPath: ImageConstant.imgLock)),
                          prefixConstraints: BoxConstraints(maxHeight: 45.v),
                          suffix: InkWell(
                              onTap: () {
                                controller.isShowPassword.value =
                                    !controller.isShowPassword.value;
                              },
                              child: Container(
                                  margin: EdgeInsets.fromLTRB(
                                      30.h, 16.v, 26.h, 14.v),
                                  child: CustomImageView(
                                      svgPath: controller.isShowPassword.value
                                          ? ImageConstant.imgGroup9
                                          : ImageConstant.imgGroup9))),
                          suffixConstraints: BoxConstraints(maxHeight: 45.v),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return "Please enter valid password";
                            }
                            return null;
                          },
                          obscureText: controller.isShowPassword.value,
                          contentPadding:
                              EdgeInsets.symmetric(vertical: 13.v))),
                      Padding(
                          padding: EdgeInsets.only(
                              left: 14.h, top: 12.v, right: 20.h),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Obx(() => CustomCheckboxButton(
                                    text: "lbl_remember_me".tr,
                                    value: controller.englishName.value,
                                    margin: EdgeInsets.only(bottom: 1.v),
                                    onChange: (value) {
                                      controller.englishName.value = value;
                                    })),
                                Opacity(
                                    opacity: 0.7,
                                    child: Text("msg_forgot_password".tr,
                                        style: CustomTextStyles
                                            .labelLargeRalewayPrimary))
                              ])),
                      SizedBox(height: 21.v),
                      CustomElevatedButton(
                          text: "lbl_login".tr,
                          onTap: () {
                            onTapLogin();
                          }),
                      Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                              padding: EdgeInsets.only(
                                  left: 9.h, top: 10.v, bottom: 5.v),
                              child: Row(children: [
                                Opacity(
                                    opacity: 0.7,
                                    child: Padding(
                                        padding: EdgeInsets.only(bottom: 1.v),
                                        child: Text("msg_i_don_t_have_an".tr,
                                            style: CustomTextStyles
                                                .labelLargeRalewayOnPrimary_1))),
                                Opacity(
                                    opacity: 0.7,
                                    child: GestureDetector(
                                        onTap: () {
                                          onTapTxtRegister();
                                        },
                                        child: Padding(
                                            padding: EdgeInsets.only(left: 6.h),
                                            child: Text("lbl_register".tr,
                                                style: CustomTextStyles
                                                    .labelLargeRalewayOnPrimary))))
                              ])))
                    ])))));
  }

  /// Navigates to the homeScreen when the action is triggered.

  /// When the action is triggered, this function uses the [Get] package to
  /// push the named route for the homeScreen.
  onTapLogin() {

    if (_formKey.currentState!.validate()) {
      controller.loginUser();

      // Form is valid, proceed to the next screen or perform your action.
      // Get.toNamed(
      //   //createIncident();
      //   //AppRoutes.complainSuccessScreen,
      // );
    }
  }

  /// Navigates to the registerScreen when the action is triggered.

  /// When the action is triggered, this function uses the [Get] package to
  /// push the named route for the registerScreen.
  onTapTxtRegister() {
    Get.toNamed(
      AppRoutes.registerScreen,
    );
  }
}
