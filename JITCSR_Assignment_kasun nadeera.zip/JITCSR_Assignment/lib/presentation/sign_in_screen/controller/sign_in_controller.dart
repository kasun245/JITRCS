import 'package:firebase_auth/firebase_auth.dart';
import 'package:jitrcs/core/app_export.dart';
import 'package:jitrcs/presentation/sign_in_screen/models/sign_in_model.dart';
import 'package:flutter/material.dart';

/// A controller class for the SignInScreen.
///
/// This class manages the state of the SignInScreen, including the
/// current signInModelObj
class SignInController extends GetxController {
  TextEditingController emailController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  Rx<SignInModel> signInModelObj = SignInModel().obs;

  Rx<bool> isShowPassword = true.obs;

  Rx<bool> englishName = false.obs;


  @override
  void onClose() {
    super.onClose();
    emailController.dispose();
    passwordController.dispose();
  }

  final FirebaseAuth _auth = FirebaseAuth.instance;

  Rx<User?> user = Rx<User?>(null);

  @override
  void onInit() {
    super.onInit();
    user.bindStream(_auth.authStateChanges());
  }
  Future<void> loginUser() async {
    try {
      await _auth.signInWithEmailAndPassword(email:emailController.text, password:passwordController.text);
      if(_auth!=null){
        Get.toNamed(AppRoutes.homeScreen);
        Get.snackbar("Login success.!",'',
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: Colors.green,
            duration: Duration(seconds: 3)
        );

      }

    } catch (e) {
      Get.snackbar("Login Failed enter valid data.!", e.toString(),
          snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
          duration: Duration(seconds: 3)
      );
      print(e);

    }

    print(user);
  }

  Future<void> logout() async {
    await _auth.signOut();
  }

}
