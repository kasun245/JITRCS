import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import '../models/transaction_model.dart';

/// A controller class for the TransactionScreen.
///
/// This class manages the state of the TransactionScreen, including the
/// current transactionModelObj
class TransactionController extends GetxController {
  Rx<TransactionModel> transactionModelObj = TransactionModel().obs;

}
