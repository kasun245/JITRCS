// import 'controller/transaction_controller.dart';
// import 'package:flutter/material.dart';
// import 'package:jitrcs/core/app_export.dart';
// import 'package:jitrcs/widgets/app_bar/appbar_title.dart';
// import 'package:jitrcs/widgets/app_bar/custom_app_bar.dart';
//
//
//
// class TransactionScreen extends GetWidget<TransactionController> {
//   const TransactionScreen(
//       {Key? key}) : super(key: key);
//
//
//
//
//   @override
//   Widget build(BuildContext context) {
//     mediaQueryData = MediaQuery.of(context);
//     var data =Get.arguments();
//     print(data);
//
//     return SafeArea(
//         child: Scaffold(
//             backgroundColor: appTheme.gray50,
//             appBar: CustomAppBar(
//                 leadingWidth: 40.h,
//                 leading: Container(
//                     height: 16.v,
//                     width: 12.h,
//                     margin:
//                         EdgeInsets.only(left: 28.h, top: 47.v, bottom: 18.v),
//                     child: Stack(alignment: Alignment.center, children: [
//                       CustomImageView(
//                           svgPath: ImageConstant.imgArrowleft,
//                           height: 16.v,
//                           width: 12.h,
//                           alignment: Alignment.center,
//                           onTap: () {
//                             onTapImgArrowleftone();
//                           }),
//                       CustomImageView(
//                           svgPath: ImageConstant.imgArrowleft,
//                           height: 16.v,
//                           width: 12.h,
//                           alignment: Alignment.center)
//                     ])),
//                 title: AppbarTitle(
//                     text: "lbl_transaction".tr,
//                     margin:
//                         EdgeInsets.only(left: 101.h, top: 46.v, bottom: 10.v)),
//                 styleType: Style.bgFill),
//
//             body: Container(
//                 width: double.maxFinite,
//                 padding: EdgeInsets.only(left: 35.h, top: 67.v, right: 35.h),
//                 child: Column(children: [
//                   Container(
//                       child: Container(
//                           child: Column(
//                               mainAxisAlignment: MainAxisAlignment.end,
//                               children: [
//                                 SizedBox(height: 5.v),
//                                 SizedBox(height: 62.v),
//                                 Row(
//                                     mainAxisAlignment:
//                                     MainAxisAlignment.spaceBetween,
//                                     children: [
//                                       Opacity(
//                                           opacity: 0.9,
//                                           child: Text(
//                                               "msg_5282_3456_7890_1289".tr,
//                                               style: CustomTextStyles
//                                                   .bodyMediumPoppinsWhiteA700)),
//                                        Text("lbl_09_25".tr,
//
//                                           style: CustomTextStyles
//                                               .bodyMediumPoppinsWhiteA700Regular)
//                                     ])
//                               ]))),
//                   Expanded(
//                     child: Padding(
//                       padding: EdgeInsets.only(
//                           left: 10.h, top: 42.v, right: 10.h),
//
//
//                       child: Obx(
//                             () => ListView.builder(
//                           itemCount: controller.transactions.length,
//                           itemBuilder: (context, index)=> Card(
//                             color: appTheme.whiteA700,
//
//                             child: ListTile(
//                               title: Column(
//                                 crossAxisAlignment: CrossAxisAlignment.start,
//                                 children: [
//                                   Text('Transaction Type : ${controller.transactions[index].transactionType!}',
//                                     style: TextStyle(
//                                       color: appTheme.indigoA700,fontSize: 16,
//                                     ),
//
//                                   ),
//                                   Text('Transaction No : ${controller.transactions[index].transactionNo.toString()}',
//                                     style: TextStyle(
//                                       color: appTheme.indigo400,fontSize: 16,
//                                     ),),
//                                   Text('Transaction amount : ${controller.transactions[index].amount!}',
//                                     style: TextStyle(
//                                       color: appTheme.indigo400,fontSize: 16,
//                                     ),),
//                                 ],
//                               ),
//                             ),
//                           ),
//                         ),
//                       ),
//                       //),
//
//
//
//
//
//                     ),),
//                 ])),
//
//         ));
//   }
//
//   /// Navigates to the previous screen.
//   ///
//   /// When the action is triggered, this function uses the [Get] package to
//   /// navigate to the previous screen in the navigation stack.
//   onTapImgArrowleftone() {
//     Get.back();
//   }
// }




import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';
import 'package:jitrcs/core/app_export.dart';

import '../../core/utils/image_constant.dart';
import '../../core/utils/size_utils.dart';
import '../../theme/app_decoration.dart';
import '../../theme/custom_button_style.dart';
import '../../theme/custom_text_style.dart';
import '../../theme/theme_helper.dart';
import '../../widgets/app_bar/appbar_title.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_image_view.dart';
import 'controller/transaction_controller.dart';

class TransactionScreen extends GetWidget<TransactionController> {
  const TransactionScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: appTheme.gray50,
            appBar: CustomAppBar(
                leadingWidth: 40.h,
                leading: Container(
                    height: 16.v,
                    width: 12.h,
                    margin:
                    EdgeInsets.only(left: 28.h, top: 47.v, bottom: 18.v),
                    child: Stack(alignment: Alignment.center, children: [
                      CustomImageView(
                          svgPath: ImageConstant.imgArrowleft,
                          height: 16.v,
                          width: 12.h,
                          alignment: Alignment.center,
                          onTap: () {
                            onTapImgArrowleftone();
                          }),
                      GestureDetector(
                        onTap: (){
                          Get.toNamed(AppRoutes.homeScreen);
                        },
                        child: CustomImageView(
                            svgPath: ImageConstant.imgArrowleft,
                            height: 16.v,
                            width: 12.h,
                            alignment: Alignment.center),
                      ),
                    ])),
                title: AppbarTitle(
                    text: "lbl_transaction".tr,
                    margin:
                    EdgeInsets.only(left: 101.h, top: 46.v, bottom: 10.v)),
                styleType: Style.bgFill),
            body: Container(
                height: 845.v,
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 23.h, vertical: 39.v),
                child: Stack(alignment: Alignment.topCenter, children: [
                  Align(
                      alignment: Alignment.topRight,
                      child: GestureDetector(
                        onTap: (){
                          Get.toNamed(AppRoutes.homeScreen);
                        },
                        child: Container(
                            margin: EdgeInsets.only(top: 269.v, right: 29.h),
                            padding: EdgeInsets.symmetric(
                                horizontal: 29.h, vertical: 9.v),
                            decoration: AppDecoration.fillTealA.copyWith(
                                borderRadius: BorderRadiusStyle.roundedBorder4),
                            child: Text("lbl_cancel".tr,
                                style: theme.textTheme.labelLarge),),
                      )),
                  Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 13.h, vertical: 18.v),
                          decoration: AppDecoration.outlineOnPrimary.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder8),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SizedBox(height: 4.v),
                                Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          children: [
                                            Text("msg_transaction_history".tr,
                                                style: theme
                                                    .textTheme.titleMedium),
                                            SizedBox(height: 6.v),
                                            Text("msg_date_of_transaction".tr,
                                                style: CustomTextStyles
                                                    .titleMediumBluegray500),
                                            SizedBox(height: 6.v),
                                            RichText(
                                                text: TextSpan(children: [
                                                  TextSpan(
                                                      text: "lbl_amount2".tr,
                                                      style: CustomTextStyles
                                                          .titleMediumBluegray50016),
                                                  TextSpan(text: " ")
                                                ]),
                                                textAlign: TextAlign.left),
                                            SizedBox(height: 8.v),
                                            RichText(
                                                text: TextSpan(children: [
                                                  TextSpan(
                                                      text:
                                                      "lbl_commission2".tr,
                                                      style: CustomTextStyles
                                                          .titleMediumBluegray50016),
                                                  TextSpan(text: " ")
                                                ]),
                                                textAlign: TextAlign.left),
                                            SizedBox(height: 9.v),
                                            RichText(
                                                text: TextSpan(children: [
                                                  TextSpan(
                                                      text: "lbl_total2".tr,
                                                      style: CustomTextStyles
                                                          .titleMediumBluegray50016),
                                                  TextSpan(text: " ")
                                                ]),
                                                textAlign: TextAlign.left),
                                            SizedBox(height: 8.v),
                                            Text("msg_transaction_number".tr,
                                                style: CustomTextStyles
                                                    .titleMediumBluegray500),
                                            SizedBox(height: 10.v),
                                            Text("msg_type_of_operation".tr,
                                                style: CustomTextStyles
                                                    .titleMediumBluegray500)
                                          ]),
                                      Padding(
                                          padding: EdgeInsets.only(
                                              left: 110.h,
                                              top: 28.v,
                                              bottom: 2.v),
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                              crossAxisAlignment: CrossAxisAlignment.end,
                                              children: [
                                                Text(//"lbl_2023_10_18".tr,
                                                  Get.arguments['date'],
                                                    style: theme
                                                        .textTheme.titleSmall),
                                                SizedBox(height: 6.v),
                                                Text(Get.arguments['amount'],
                                                  //"lbl_200000_lkr2".tr,
                                                    style: theme
                                                        .textTheme.titleSmall),
                                                SizedBox(height: 6.v),
                                                Text(//"lbl_5".tr,
                                                    Get.arguments['commission'],
                                                    style: theme
                                                        .textTheme.titleSmall),
                                                SizedBox(height: 13.v),
                                                Text(//"lbl_3500_000".tr,
                                                    Get.arguments['total'],
                                                    style: theme
                                                        .textTheme.titleSmall),
                                                SizedBox(height: 9.v),
                                                Text(Get.arguments['tranactionNo'],
                                                    //"msg_2271_5214_8547_9658".tr,
                                                    style: theme
                                                        .textTheme.titleSmall),
                                                SizedBox(height: 10.v),
                                                Text(//"lbl_transfer".tr,
                                                  Get.arguments['tranactionType'],
                                                    style: theme
                                                        .textTheme.titleSmall)
                                              ]))
                                    ]),
                                CustomElevatedButton(
                                    height: 34.v,
                                    width: 112.h,
                                    text: "lbl_cancel".tr,
                                    margin:
                                    EdgeInsets.only(top: 60.v, right: 11.h),
                                    buttonStyle: CustomButtonStyles.fillPink,
                                    buttonTextStyle:
                                    theme.textTheme.labelLarge!)
                              ])))
                ]))));
  }

  /// Navigates to the previous screen.
  ///
  /// When the action is triggered, this function uses the [Get] package to
  /// navigate to the previous screen in the navigation stack.
  onTapImgArrowleftone() {
    Get.back();
  }
}
