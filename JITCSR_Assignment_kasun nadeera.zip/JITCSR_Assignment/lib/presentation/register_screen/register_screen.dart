import 'controller/register_controller.dart';
import 'package:flutter/material.dart';
import 'package:jitrcs/core/app_export.dart';
import 'package:jitrcs/core/utils/validation_functions.dart';
import 'package:jitrcs/widgets/custom_elevated_button.dart';
import 'package:jitrcs/widgets/custom_text_form_field.dart';

// ignore_for_file: must_be_immutable
class RegisterScreen extends GetWidget<RegisterController> {
  RegisterScreen({Key? key}) : super(key: key);

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: Form(
                key: _formKey,
                child: Container(
                    width: 414.h,
                    padding:
                        EdgeInsets.symmetric(horizontal: 34.h, vertical: 45.v),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomElevatedButton(
                              height: 25.v,
                              width: 118.h,
                              text: "lbl_go_back".tr,
                              leftIcon: Container(
                                  margin: EdgeInsets.only(right: 14.h),
                                  child: CustomImageView(
                                      svgPath:
                                          ImageConstant.imgArrowleftOnprimary)),
                              buttonStyle: CustomButtonStyles.none,
                              buttonTextStyle:
                                  CustomTextStyles.titleLargeOnPrimary,
                              onTap: () {
                                onTapGoback();
                              }),
                          Spacer(),
                          Align(
                              alignment: Alignment.center,
                              child: SizedBox(
                                  height: 69.v,
                                  width: 168.h,
                                  child: Stack(
                                      alignment: Alignment.topCenter,
                                      children: [
                                        Align(
                                            alignment: Alignment.bottomCenter,
                                            child: Column(
                                                mainAxisSize: MainAxisSize.min,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Padding(
                                                      padding: EdgeInsets.only(
                                                          left: 42.h),
                                                      child: Text(
                                                          "lbl_jitrcs".tr,
                                                          style: CustomTextStyles
                                                              .titleLargeIndigo400)),
                                                  SizedBox(height: 5.v),
                                                  Text(
                                                      "msg_sign_up_in_to_continue"
                                                          .tr,
                                                      style: CustomTextStyles
                                                          .titleSmallRalewayOnPrimaryContainer)
                                                ])),
                                        Align(
                                            alignment: Alignment.topCenter,
                                            child: Text("lbl_sign_in".tr,
                                                style:
                                                    theme.textTheme.titleLarge))
                                      ]))),
                          SizedBox(height: 57.v),
                          Opacity(
                              opacity: 0.7,
                              child: Text("lbl_name".tr,
                                  style: CustomTextStyles
                                      .titleSmallRalewayOnPrimary)),
                          SizedBox(height: 3.v),
                          CustomTextFormField(
                              controller: controller.nameController,
                              hintText: "lbl_jitrcs2".tr,
                              prefix: Container(
                                  margin: EdgeInsets.fromLTRB(
                                      12.h, 13.v, 30.h, 13.v),
                                  child: CustomImageView(
                                      svgPath: ImageConstant.imgMail)),
                              prefixConstraints:
                                  BoxConstraints(maxHeight: 46.v)),
                          SizedBox(height: 28.v),
                          Opacity(
                              opacity: 0.7,
                              child: Text("lbl_email".tr,
                                  style: CustomTextStyles
                                      .titleSmallRalewayOnPrimary)),
                          SizedBox(height: 5.v),
                          CustomTextFormField(
                              controller: controller.emailController,
                              hintText: "msg_jitrcs_gmail_com".tr,
                              textInputType: TextInputType.emailAddress,
                              prefix: Container(
                                  margin: EdgeInsets.fromLTRB(
                                      12.h, 13.v, 30.h, 13.v),
                                  child: CustomImageView(
                                      svgPath: ImageConstant.imgMail)),
                              prefixConstraints:
                                  BoxConstraints(maxHeight: 46.v),
                              validator: (value) {
                                if (value == null ||
                                    (!isValidEmail(value, isRequired: true))) {
                                  return "Please enter valid email";
                                }
                                return null;
                              }),
                          Opacity(
                              opacity: 0.7,
                              child: Padding(
                                  padding:
                                      EdgeInsets.only(left: 2.h, top: 28.v),
                                  child: Text("lbl_password".tr,
                                      style: CustomTextStyles
                                          .titleSmallRalewayOnPrimary))),
                          SizedBox(height: 3.v),
                          Obx(() => CustomTextFormField(
                              controller: controller.passwordController,
                              hintText: "lbl".tr,
                              hintStyle: CustomTextStyles
                                  .titleSmallRalewayPrimaryContainer,
                              textInputAction: TextInputAction.done,
                              textInputType: TextInputType.visiblePassword,
                              prefix: Container(
                                  margin:
                                      EdgeInsets.fromLTRB(11.h, 9.v, 21.h, 9.v),
                                  child: CustomImageView(
                                      svgPath: ImageConstant.imgLock)),
                              prefixConstraints:
                                  BoxConstraints(maxHeight: 46.v),
                              suffix: InkWell(
                                  onTap: () {
                                    controller.isShowPassword.value =
                                        !controller.isShowPassword.value;
                                  },
                                  child: Container(
                                      margin: EdgeInsets.fromLTRB(
                                          30.h, 16.v, 26.h, 14.v),
                                      child: CustomImageView(
                                          svgPath:
                                              controller.isShowPassword.value
                                                  ? ImageConstant.imgGroup9
                                                  : ImageConstant.imgGroup9))),
                              suffixConstraints:
                                  BoxConstraints(maxHeight: 46.v),
                              validator: (value) {
                                if (value == null ||
                                    (!isValidPassword(value,
                                        isRequired: true))) {
                                  return "Please enter valid password";
                                }
                                return null;
                              },
                              obscureText: controller.isShowPassword.value,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 14.v))),
                          SizedBox(height: 21.v),
                          CustomElevatedButton(
                              text: "lbl_register".tr,
                              onTap: () {
                                onTapRegister();
                              }),
                          Padding(
                              padding: EdgeInsets.only(
                                  left: 25.h, top: 18.v, bottom: 18.v),
                              child: Row(children: [
                                Opacity(
                                    opacity: 0.7,
                                    child: Padding(
                                        padding: EdgeInsets.only(top: 1.v),
                                        child: Text("msg_i_already_register".tr,
                                            style: CustomTextStyles
                                                .labelLargeRalewayOnPrimary_1))),
                                Opacity(
                                    opacity: 0.7,
                                    child: GestureDetector(
                                        onTap: () {
                                          onTapTxtLogin();
                                        },
                                        child: Padding(
                                            padding: EdgeInsets.only(left: 4.h),
                                            child: Text("lbl_login2".tr,
                                                style: CustomTextStyles
                                                    .labelLargeRalewayIndigoA700))))
                              ]))
                        ])))));
  }

  /// Navigates to the signInScreen when the action is triggered.

  /// When the action is triggered, this function uses the [Get] package to
  /// push the named route for the signInScreen.
  onTapGoback() {
    Get.toNamed(
      AppRoutes.signInScreen,
    );
  }

  /// Navigates to the signInScreen when the action is triggered.

  /// When the action is triggered, this function uses the [Get] package to
  /// push the named route for the signInScreen.
  onTapRegister() {
    Get.toNamed(
      AppRoutes.signInScreen,
    );
  }

  /// Navigates to the signInScreen when the action is triggered.

  /// When the action is triggered, this function uses the [Get] package to
  /// push the named route for the signInScreen.
  onTapTxtLogin() {
    Get.toNamed(
      AppRoutes.signInScreen,
    );
  }
}
