import 'package:get/get.dart';
import 'package:jitrcs/presentation/home_screen/models/home_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../../../data/models/transaction/transactionDataModel.dart';


class HomeController extends GetxController {
  Rx<HomeModel> homeModelObj = HomeModel().obs;


  FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;
  RxList<TransactionData> transactions = RxList<TransactionData>([]);
  late CollectionReference collectionReference;

  @override
  void onInit() {
    super.onInit();
    collectionReference = firebaseFirestore.collection("transaction");
    transactions.bindStream(getAllTransaction());

  }

  Stream<List<TransactionData>> getAllTransaction() =>
      collectionReference.snapshots().map((query) =>
          query.docs.map((item) => TransactionData.fromMap(item)).toList());




}




