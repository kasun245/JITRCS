import '../controller/home_controller.dart';
import '../models/transactiondeta_item_model.dart';
import 'package:flutter/material.dart';
import 'package:jitrcs/core/app_export.dart';

// ignore: must_be_immutable
class TransactiondetaItemWidget extends StatelessWidget {
  TransactiondetaItemWidget(
    this.transactiondetaItemModelObj, {
    Key? key,
    this.onTapTransactiondeta,
  }) : super(
          key: key,
        );

  TransactiondetaItemModel transactiondetaItemModelObj;
  //TransactionData transactionDataobj=TransactionData()

  var controller = Get.find<HomeController>();

  VoidCallback? onTapTransactiondeta;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        onTapTransactiondeta?.call();
      },
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: 19.h,
          vertical: 23.v,
        ),
        decoration: AppDecoration.outlineOnPrimary.copyWith(
          borderRadius: BorderRadiusStyle.roundedBorder8,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.only(right: 51.h),
              child: Row(
                children: [
                  Text(
                    "msg_type_of_transaction".tr,
                    style: theme.textTheme.titleMedium,
                  ),
                  Padding(
                    padding: EdgeInsets.only(left: 9.h),
                    child: Obx(
                      () => Text(
                        transactiondetaItemModelObj.transactionDepo!.value,
                        overflow: TextOverflow.ellipsis,
                        style: CustomTextStyles.titleMediumTealA700,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                top: 10.v,
                right: 7.h,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: "msg_transaction_no2".tr,
                          style: CustomTextStyles.titleSmallBluegray500_1,
                        ),
                        TextSpan(
                          text: " ",
                        ),
                      ],
                    ),
                    textAlign: TextAlign.left,
                  ),
                  Text(
                    "msg_2271_5214_8547_9658".tr,
                    style: theme.textTheme.titleSmall,
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                top: 11.v,
                right: 46.h,
              ),
              child: Row(
                children: [
                  Text(
                    "msg_transaction_amount".tr,
                    style: CustomTextStyles.titleSmallBluegray500,
                  ),
                  Padding(
                    padding: EdgeInsets.only(left: 12.h),
                    child: Text(
                      "lbl_200000lkr".tr,
                      style: CustomTextStyles.titleMediumTealA70016,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
