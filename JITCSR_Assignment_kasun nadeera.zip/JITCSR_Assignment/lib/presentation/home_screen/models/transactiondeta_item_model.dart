import '../../../core/app_export.dart';

/// This class is used in the [transactiondeta_item_widget] screen.
 class TransactiondetaItemModel {
  // TransactiondetaItemModel({
  //   this.transactionDepo,
  //   this.id,
  // }) {
  //   transactionDepo = transactionDepo ?? Rx("Deposit");
  //   id = id ?? Rx("");
  // }

  Rx<String>? transactionDepo = Rx("");
  Rx<String>? transactionNo = Rx("");
  Rx<String>? transactionAmmount = Rx("");

  Rx<String>? id;
}
