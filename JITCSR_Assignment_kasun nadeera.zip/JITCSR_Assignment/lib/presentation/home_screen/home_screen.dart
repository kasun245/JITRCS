import '../home_screen/widgets/transactiondeta_item_widget.dart';
import '../transaction_screen/transaction_screen.dart';
import 'controller/home_controller.dart';
import 'models/transactiondeta_item_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;
import 'package:jitrcs/core/app_export.dart';
import 'package:jitrcs/widgets/app_bar/appbar_image.dart';
import 'package:jitrcs/widgets/app_bar/appbar_title.dart';
import 'package:jitrcs/widgets/app_bar/custom_app_bar.dart';

class HomeScreen extends GetWidget<HomeController> {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: appTheme.gray50,
            appBar: CustomAppBar(
                leadingWidth: 40.h,
                leading: AppbarImage(
                    svgPath: ImageConstant.imgArrowleft,
                    margin:
                        EdgeInsets.only(left: 28.h, top: 47.v, bottom: 18.v),
                    onTap: () {
                      onTapArrowleftone();
                    }),
                centerTitle: true,
                title: AppbarTitle(
                    text: "lbl_home".tr,
                    margin: EdgeInsets.only(top: 47.v, bottom: 10.v)),
                styleType: Style.bgFill),
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.only(left: 35.h, top: 67.v, right: 35.h),
                child: Column(children: [
                  Container(
                      decoration: AppDecoration.gradientDeepPurpleAToIndigoA
                          .copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder30),
                      child: Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 33.h, vertical: 22.v),
                          decoration: BoxDecoration(
                              image: DecorationImage(
                                  image: fs.Svg(ImageConstant.imgGroup2),
                                  fit: BoxFit.cover)),
                          child: Column(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                SizedBox(height: 5.v),
                                Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                          padding: EdgeInsets.only(top: 5.v),
                                          child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Opacity(
                                                    opacity: 0.54,
                                                    child: Text(
                                                        "lbl_current_balance"
                                                            .tr,
                                                        style: CustomTextStyles
                                                            .bodyMediumPoppinsWhiteA700Regular14)),
                                                SizedBox(height: 5.v),
                                                Text("lbl_5_750_20".tr,
                                                    style: theme.textTheme
                                                        .headlineMedium)
                                              ])),
                                      CustomImageView(
                                          svgPath: ImageConstant.imgUser,
                                          height: 40.v,
                                          width: 50.h,
                                          margin: EdgeInsets.only(bottom: 32.v))
                                    ]),
                                SizedBox(height: 62.v),
                                Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Opacity(
                                          opacity: 0.9,
                                          child: Text(
                                              "msg_5282_3456_7890_1289".tr,
                                              style: CustomTextStyles
                                                  .bodyMediumPoppinsWhiteA700)),
                                      Text("lbl_09_25".tr,
                                          style: CustomTextStyles
                                              .bodyMediumPoppinsWhiteA700Regular)
                                    ])
                              ]))),
                  Expanded(
                      child: Padding(
                          padding: EdgeInsets.only(
                              left: 0.h, top: 42.v, right: 0.h),
                          child: Obx(
                              () => ListView.builder(
                                  itemCount: controller.transactions.length,
                              itemBuilder: (context, index)=> Card(
                                color: appTheme.whiteA700,

                                child: ListTile(
                                  trailing: const Icon(Icons.arrow_forward),
                                  onTap: () {
                                    onTapTransactiondeta?.call();
                                    Get.to(
                                      TransactionScreen(),
                                      arguments: {
                                        "tranactionType":"${controller.transactions[index].transactionType!}",
                                        "tranactionNo":"${controller.transactions[index].transactionNo.toString()}",
                                        "amount":"${controller.transactions[index].amount}",
                                        "commission":"${controller.transactions[index].commission!}",
                                        "total":"${controller.transactions[index].total!}",
                                        "date":"${controller.transactions[index].date!}",
                                      }, // Pass the transaction data
                                    );
                                  },
                                  title: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text('Transaction Type : ${controller.transactions[index].transactionType!}',
                                        style: TextStyle(
                                          color: appTheme.tealA700,fontSize: 16,
                                        ),

                                      ),
                                      Text('Transaction amount : ${controller.transactions[index].amount!}',
                                        style: TextStyle(
                                          color: appTheme.blueGray400,fontSize: 16,
                                        ),),
                                      Text('Transaction No : ${controller.transactions[index].transactionNo.toString()}',
                                        style: TextStyle(
                                          color: appTheme.blueGray900,fontSize: 16,
                                        ),),
                                    ],
                                  ),
                                ),
                              ),
                              ),
                          ),
                        //),





                          ),),
                ]))
        ),
    );
  }

  /// Navigates to the transactionScreen when the action is triggered.
  /// When the action is triggered, this function uses the [Get] package to
  /// push the named route for the transactionScreen.
  onTapTransactiondeta() {
    Get.toNamed(AppRoutes.transactionScreen);
    // Get.to(
    //   TransactionScreen(),
    //   //arguments: controller.transactions[index], // Pass the transaction data
    // );
  }

  /// Navigates to the previous screen.
  ///
  /// When the action is triggered, this function uses the [Get] package to
  /// navigate to the previous screen in the navigation stack.
  onTapArrowleftone() {
    Get.back();
  }
}
