class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // home images
  static String imgGroup2 = '$imagePath/img_group2.svg';

  static String imgUser = '$imagePath/img_user.svg';

  // Register images
  static String imgArrowleftOnprimary =
      '$imagePath/img_arrowleft_onprimary.svg';

  // Common images
  static String imgMail = '$imagePath/img_mail.svg';

  static String imgLock = '$imagePath/img_lock.svg';

  static String imgGroup9 = '$imagePath/img_group_9.svg';

  static String imgArrowleft = '$imagePath/img_arrowleft.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
