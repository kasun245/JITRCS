import 'package:cloud_firestore/cloud_firestore.dart';

class TransactionData{
  String? transactionType;
  int? transactionNo;
  String? amount;
  String? commission;
  int? total;
  String? date;
  TransactionData({
    this.amount,
    this.transactionNo,
    this.transactionType,
    this.commission,
    this.total,
    this.date,
});
  TransactionData.fromMap(DocumentSnapshot data){
    amount = data["Transaction_amount"];
    transactionNo= data["Transaction_number"];
    transactionType= data["Type_of_transaction"];
    commission= data["Commission"];
    total=data["Total"];
    date=data["Transaction_date"];
  }
}