import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get_connect/connect.dart';

import '../models/transaction/transactionDataModel.dart';

class ApiClient extends GetConnect {}

class FirebaseService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<List<TransactionData>> fetchTransactions() async {
    QuerySnapshot querySnapshot = await _firestore.collection('transactions').get();
    return querySnapshot.docs.map((doc) {
      Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
      return TransactionData.fromMap(data as DocumentSnapshot<TransactionData?>);
    }).toList();
  }
}