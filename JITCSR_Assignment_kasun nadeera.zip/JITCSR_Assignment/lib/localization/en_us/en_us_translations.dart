final Map<String, String> enUs = {
  // Sign in Screen
  "lbl_login": "Login",
  "lbl_remember_me": "Remember me",
  "msg_forgot_password": "Forgot Password?",
  "msg_i_don_t_have_an": "I Don’t Have An Account :",
  "msg_sign_in_to_continue": "Sign in to continue.",

  // home Screen
  "lbl_09_25": "09/25",
  "lbl_200000lkr": "200000LKR",
  "lbl_5_750_20": "\$5,750,20",
  "lbl_current_balance": "Current Balance",
  "lbl_deposit": "Deposit",
  "lbl_home": "Home",
  "lbl_withdrawal": "withdrawal",
  "msg_5282_3456_7890_1289": "5282 3456 7890 1289",
  "msg_transaction_amount": "Transaction amount :",
  "msg_transaction_no": "Transaction No :   ",
  "msg_transaction_no2": "Transaction No :  ",
  "msg_type_of_transaction": "Type of transaction :",

  // transaction Screen
  "lbl_200000_lkr2": "200000 LKR",
  "lbl_2023_10_18": "2023-10-18",
  "lbl_3500_000": "3500 000",
  "lbl_5": "5%",
  "lbl_amount": "Amount :  ",
  "lbl_amount2": "Amount : ",
  "lbl_cancel": "Cancel",
  "lbl_commission": "Commission :  ",
  "lbl_commission2": "Commission : ",
  "lbl_total": "Total :  ",
  "lbl_total2": "Total : ",
  "lbl_transaction": "Transaction",
  "lbl_transfer": "transfer",
  "msg_date_of_transaction": "Date Of transaction :",
  "msg_transaction_history": "Transaction History",
  "msg_transaction_number": "Transaction number :",
  "msg_type_of_operation": "Type of operation :",

  // Register Screen
  "lbl_go_back": "Go Back",
  "lbl_jitrcs2": "JITRCS",
  "lbl_login2": "LOGIN",
  "lbl_name": "name",
  "msg_i_already_register": "I Already Register :",
  "msg_sign_up_in_to_continue": "Sign up in to continue.",

  // Common String
  "lbl": "***********",
  "lbl_email": "Email",
  "lbl_jitrcs": "JITRCS,",
  "lbl_password": "Password",
  "lbl_register": "Register",
  "lbl_sign_in": "Sign In",
  "msg_2271_5214_8547_9658": "2271-5214-8547-9658",
  "msg_jitrcs_gmail_com": "jitrcs@gmail.com",

  // App navigation Screen
  "lbl_app_navigation": "App Navigation",
  "lbl_home2": "home",
  "lbl_sign_in2": "Sign in",
  "lbl_transaction2": "transaction",
  "msg_check_your_app_s":
      "Check your app's UI from the below demo screens of your app.",

// Network Error String
  "msg_network_err": "Network Error",
  "msg_something_went_wrong": "Something Went Wrong!",
};
