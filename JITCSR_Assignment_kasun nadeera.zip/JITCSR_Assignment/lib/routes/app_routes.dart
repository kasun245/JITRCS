import 'package:jitrcs/presentation/sign_in_screen/sign_in_screen.dart';
import 'package:jitrcs/presentation/sign_in_screen/binding/sign_in_binding.dart';
import 'package:jitrcs/presentation/home_screen/home_screen.dart';
import 'package:jitrcs/presentation/home_screen/binding/home_binding.dart';
import 'package:jitrcs/presentation/transaction_screen/transaction_screen.dart';
import 'package:jitrcs/presentation/transaction_screen/binding/transaction_binding.dart';
import 'package:jitrcs/presentation/register_screen/register_screen.dart';
import 'package:jitrcs/presentation/register_screen/binding/register_binding.dart';
import 'package:jitrcs/presentation/app_navigation_screen/app_navigation_screen.dart';
import 'package:jitrcs/presentation/app_navigation_screen/binding/app_navigation_binding.dart';
import 'package:get/get.dart';

class AppRoutes {
  static const String signInScreen = '/sign_in_screen';

  static const String homeScreen = '/home_screen';

  static const String transactionScreen = '/transaction_screen';

  static const String registerScreen = '/register_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static List<GetPage> pages = [
    GetPage(
      name: signInScreen,
      page: () => SignInScreen(),
      bindings: [
        SignInBinding(),
      ],
    ),
    GetPage(
      name: homeScreen,
      page: () => HomeScreen(),
      bindings: [
        HomeBinding(),
      ],
    ),
    GetPage(
      name: transactionScreen,
      page: () => TransactionScreen(),
      bindings: [
        TransactionBinding(),
      ],
    ),
    GetPage(
      name: registerScreen,
      page: () => RegisterScreen(),
      bindings: [
        RegisterBinding(),
      ],
    ),
    GetPage(
      name: appNavigationScreen,
      page: () => AppNavigationScreen(),
      bindings: [
        AppNavigationBinding(),
      ],
    ),
    GetPage(
      name: initialRoute,
      page: () => SignInScreen(),
      bindings: [
        SignInBinding(),
      ],
    )
  ];
}
