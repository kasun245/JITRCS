
# jitrcs
Flutter 3.13.8 • channel stable
Tools • Dart 3.1.4 • DevTools 2.25.0
JITRCS - Assignment 1 flutter app 


### Support
kasun nadeera rathnayka
kasunnrathnayke@gmail.com JITRCS - Assignment
