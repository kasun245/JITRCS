package com.jitrcs.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
